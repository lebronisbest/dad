import React from 'react';
import CalendarContainer from '../calendar/CalendarContainer';

const ScheduleManager = () => {
  return <CalendarContainer />;
};

export default ScheduleManager;
